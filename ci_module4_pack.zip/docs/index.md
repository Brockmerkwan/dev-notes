# Dev Notes

This site is built automatically by **GitHub Actions** using **MkDocs**.

- Your living README is in the repo root.
- Add Markdown files under the `docs/` folder — they will appear in the site.

> Tip: run `mkdocs serve` locally to preview at http://localhost:8000
